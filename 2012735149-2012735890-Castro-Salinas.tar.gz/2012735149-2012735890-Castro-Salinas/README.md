Tarea2SO
========
José Miguel Castro 	201273514-9
Marco Antonio Salinas	201273589-0
========

Compilación:	$ make
Uso:	     		$ ./Tarea2SO <#Repeticiones> <TiempoEspera>
